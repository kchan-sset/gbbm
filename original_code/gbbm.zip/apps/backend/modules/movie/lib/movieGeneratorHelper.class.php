<?php

/**
 * movie module helper.
 *
 * @package    gbbm
 * @subpackage movie
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class movieGeneratorHelper extends BaseMovieGeneratorHelper
{
}
