<?php

/**
 * featured_pair module helper.
 *
 * @package    gbbm
 * @subpackage featured_pair
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class featured_pairGeneratorHelper extends BaseFeatured_pairGeneratorHelper
{
}
