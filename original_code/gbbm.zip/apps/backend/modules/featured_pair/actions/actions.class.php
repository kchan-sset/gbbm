<?php

require_once dirname(__FILE__).'/../lib/featured_pairGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/featured_pairGeneratorHelper.class.php';

/**
 * featured_pair actions.
 *
 * @package    gbbm
 * @subpackage featured_pair
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class featured_pairActions extends autoFeatured_pairActions
{
}
