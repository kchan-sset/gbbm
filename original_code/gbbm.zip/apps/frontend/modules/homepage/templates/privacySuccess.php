<?php $sf_response->setTitle('GBBM: Privacy Policy') ?>
<div class="col2 clearfix mainCol">
<p>
	GBBM - Good Beer. Bad Movie. does not collect or store information about its users beyond simple anonymous analytics and usage statistics. All personalization features 
	are provided by 3<sup>rd</sup> party providers and are implemented per their API standards. You can review their policies below;
</p>
<ul>
	<li><a href="http://www.facebook.com/privacy/explanation.php" title="Facebook Privacy Policy">Facebook Privacy Policy</a></li>
	<li><a href="http://www.netflix.com/PrivacyPolicy" title="Netflix Privacy Policy">Netflix Privacy Policy</a></li>
</div>
<!-- end colThree -->
