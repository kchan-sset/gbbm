<div id="twit" class="socialBtn">
<a href="http://twitter.com/share"
	class="twitter-share-button"
	data-count="horizontal"
	data-url="<?php echo $url ?>"
	<? /* data-counturl="http://goodbeerbadmovie.com" */ ?>
  data-text="<?php echo $title ?>"
>Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
</div>