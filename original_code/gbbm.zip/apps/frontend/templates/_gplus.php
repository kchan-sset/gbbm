<div id="gplus" class="socialBtn">
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<g:plusone size="medium" count="true" href="<?php echo $url ?>"></g:plusone>
</div>