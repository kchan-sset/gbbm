<?php

/**
 * User form.
 *
 * @package    form
 * @subpackage User
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class UserForm extends BaseUserForm
{
  public function configure()
  {
  	$this->widgetSchema['password'] = new sfWidgetFormInputPassword(array('always_render_empty' => false));
  }
}