<td>
  <input type="checkbox" name="ids[]" value="<?php echo $movie->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
</td>
