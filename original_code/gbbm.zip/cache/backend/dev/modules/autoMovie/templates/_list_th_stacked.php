<?php include_partial('movie/list_th_tabular', array('sort' => $sort)) ?>
