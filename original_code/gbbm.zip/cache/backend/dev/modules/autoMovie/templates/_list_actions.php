<?php echo $helper->linkToNew(array(  'params' =>   array(  ),  'class_suffix' => 'new',  'label' => 'New',)) ?>
<li class="sf_admin_action_lookup">
  <?php echo link_to(__('Lookup', array(), 'messages'), 'movie/lookup', array()) ?>
</li>
