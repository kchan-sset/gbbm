<td class="sf_admin_text sf_admin_list_td_id">
  <?php echo link_to($featured_pair->getId(), 'featured_pair_edit', $featured_pair) ?>
</td>
<td class="sf_admin_text sf_admin_list_td_beerName">
  <?php echo link_to($featured_pair->getBeerName(), 'featured_pair_edit', $featured_pair) ?>
</td>
<td class="sf_admin_text sf_admin_list_td_movieName">
  <?php echo link_to($featured_pair->getMovieName(), 'featured_pair_edit', $featured_pair) ?>
</td>
