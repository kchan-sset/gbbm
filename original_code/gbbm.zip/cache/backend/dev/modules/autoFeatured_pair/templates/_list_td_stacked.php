<td colspan="3">
  <?php echo __('%%id%% - %%beerName%% - %%movieName%%', array('%%id%%' => link_to($featured_pair->getId(), 'featured_pair_edit', $featured_pair), '%%beerName%%' => link_to($featured_pair->getBeerName(), 'featured_pair_edit', $featured_pair), '%%movieName%%' => link_to($featured_pair->getMovieName(), 'featured_pair_edit', $featured_pair)), 'messages') ?>
</td>
