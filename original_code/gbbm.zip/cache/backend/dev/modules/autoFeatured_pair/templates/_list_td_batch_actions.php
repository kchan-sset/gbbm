<td>
  <input type="checkbox" name="ids[]" value="<?php echo $featured_pair->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
</td>
