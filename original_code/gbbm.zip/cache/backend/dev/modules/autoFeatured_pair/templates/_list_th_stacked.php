<?php include_partial('featured_pair/list_th_tabular', array('sort' => $sort)) ?>
