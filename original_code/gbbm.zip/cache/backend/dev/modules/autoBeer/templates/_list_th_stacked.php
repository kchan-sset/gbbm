<?php include_partial('beer/list_th_tabular', array('sort' => $sort)) ?>
